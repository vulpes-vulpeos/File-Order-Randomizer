#include <iostream>
#include <filesystem> //for std::filesystem
#include <fstream>    //for ifstream
#include <random>     //for mersenne()
#include <cstdio>     //for c_str()
#include <cctype>     //for isdigit()
#include <cmath>      //for pow()
#include <vector>     //for vector
#include <unistd.h>   //for getlogin()

enum Errors {
	WRONG_OPTION = 1,
	WRONG_PATH = 2,
	PATH_DO_NOT_EXIST = 3
};

struct FilePaths {
	std::string originalPath;
	std::string newPath;
};

bool macOsJunkChecker(std::string &pathToFile)
{
	bool junk = false;
	std::vector<std::string> macOsJunk = {".DS_Store", ".localized", "$RECYCLE.BIN",
	".fseventsd", ".Spotlight-V100", "System Volume Information"};

	for (int i = 0; i < macOsJunk.size(); ++i)
	{
		if (pathToFile.find(macOsJunk[i]) != std::string::npos)
		{
			junk = true;
			break;
		};
	};

	return junk;
}

bool numberCheck(std::string &fileName)
{
	bool check = isdigit(fileName[0]);

	return check;
}

int findSeparator(std::string &fileName)
{
	std::string separators[] = {"_",". "};

	int index = fileName.find(separators[0]);
	if (index == std::string::npos)
	{
		index = fileName.find(separators[1]);
		if (index != std::string::npos)
		{
			index += 1;
		}
		else if (index == std::string::npos)
		{
			index = 0;
		};
	};

	return index;
}

std::string numberRemove(std::string fileName, int index)
{
	fileName.erase(0,index+1);
	return fileName;
}

void progressBar(const int filesParsed, const int numberOfFiles)
{
	int currentPercent = (filesParsed*100)/numberOfFiles;
	int filled = (currentPercent*50)/100;
	int empty = 50-filled;
	std::string filler;
	for (int i = 0; i < filled; ++i)
	{
		filler += "#";
	};
	for (int i = 0; i < empty; ++i)
	{
		filler += " ";
	};

	std::cout << "[" << filler << "] " << currentPercent << "% | " << filesParsed << " of " << numberOfFiles << "\r";
}

void renameFile(std::vector<FilePaths> &renameQueue)
{
	int filesParsed = 0, totalNumber = renameQueue.size();
	for (int i = 0; i < totalNumber; ++i){
		const char *char_oldName = renameQueue[i].originalPath.c_str();
		const char *char_newName = renameQueue[i].newPath.c_str();

		int result = rename(char_oldName, char_newName);
		if (result != 0)
		{
			perror("Couldn't rename file (ʘдʘ╬)");
		};

		++filesParsed;
		progressBar(filesParsed, totalNumber);
	};

	std::cout << std::endl;
}

void loadFilterlist(std::string &launchFolder, std::vector<std::string> &triggers)
{
	//Get path to filter file
	std::string pathToFilterFile = launchFolder;
	int index = pathToFilterFile.find_last_of("/");
	pathToFilterFile.resize(index);
	pathToFilterFile += "/forand_filterlist.txt";

	if (!std::filesystem::exists(pathToFilterFile))
	{
		std::cout << "Loaded built-in filters." << std::endl;
		triggers = {"а", "А", "е", "Е", "ё", "Ё", "и", "И", "о", "О", "у", "У", "э", "Э", "ю", "Ю", "я", "Я"};
	}
	else
	{
		std::cout << "Loading filter list from " << pathToFilterFile << std::endl;

		std::string line;
		int i = 0;
		std::ifstream file (pathToFilterFile);

		if (file.is_open())
		{
			while (getline(file, line, ','))
			{
				triggers.push_back(line);
				++i;
			};
		};

		file.close();
	};
}

void filterFunction(std::string &pathToFolder, std::string &launchFolder)
{
	std::vector<FilePaths> renameQueue;
	FilePaths currentFile;
	std::vector<std::string> triggers;
	loadFilterlist(launchFolder, triggers);
	for (const auto &entry : std::filesystem::directory_iterator(pathToFolder))
	{
		std::string pathToFile = entry.path();
		int index = pathToFile.find_last_of("/");
		std::string fileName = pathToFile.substr(index+1);
		std::string username = getlogin();

		if(!macOsJunkChecker(fileName))
		{
			for (int i = 0; i<triggers.size(); ++i)
			{
				if (fileName.find(triggers[i]) != std::string::npos)
				{
					/* 
					//Deletes files without moving them to trash
					const char * char_pathToFile = pathToFile.c_str();
					if (remove(char_pathToFile) != 0) {perror("Couldn't delete file (ʘдʘ╬)");}
					*/

					std::string newName = "/Users/" + username + "/.Trash/" + fileName;

					currentFile.originalPath = pathToFile;
					currentFile.newPath = newName;
					renameQueue.push_back(currentFile);

					break;
				};
			};
		};
	};

	renameFile(renameQueue);
}

int randomNumberGen(int randomNumberMax)
{
	int randomNumber;
	std::random_device rd; 
	std::mt19937 mersenne(rd());
	std::uniform_int_distribution dist{0, randomNumberMax};
	
	randomNumber = dist(mersenne);

	return randomNumber;
}

std::string ranNumProcessing(int randomNumber, int numberLenght)
{
	int digitsInRandomNumber = std::to_string(randomNumber).size();
	std::string procRandomNumber;

	if (digitsInRandomNumber < numberLenght)
	{
		std::string prefix = "0"; 
		for (int i = 1; i < numberLenght-digitsInRandomNumber; ++i)
		{
			prefix += "0";
		};
		procRandomNumber = prefix + std::to_string(randomNumber);
	}
	else 
	{
		procRandomNumber = std::to_string(randomNumber);
	};

	return procRandomNumber;
}

std::size_t numberOfFilesInDirectory(const std::filesystem::path &path)
{
    std::size_t numberOfFiles = std::distance(std::filesystem::directory_iterator(path), std::filesystem::directory_iterator{});
    return numberOfFiles;
}

void randomizeFunction(std::string &pathToFolder)
{
	int numberOfFiles = numberOfFilesInDirectory(pathToFolder);
	int numberLenght = std::to_string(numberOfFiles).size();
	int randomNumberMax = pow(10, numberLenght)-1;
	std::vector<FilePaths> renameQueue;
	FilePaths currentFile;

	for (const auto &entry : std::filesystem::directory_iterator(pathToFolder))
	{
		std::string pathToFile = entry.path();

		int index = pathToFile.find_last_of("/\\");
		std::string fileName = pathToFile.substr(index+1);

		if(!macOsJunkChecker(fileName))
		{
			if(numberCheck(fileName))
			{
				int index = findSeparator(fileName);
				if(index != 0)
				{
					fileName = numberRemove(fileName, index);
				};
			};

			std::string newName = pathToFolder + "/" + ranNumProcessing(randomNumberGen(randomNumberMax), numberLenght)
								+ "_" + static_cast<std::string>(fileName);

			currentFile.originalPath = pathToFile;
			currentFile.newPath = newName;
			renameQueue.push_back(currentFile);
		};
	};

	renameFile(renameQueue);
}

void unrandomizeFunction(std::string &pathToFolder)
{
	std::vector<FilePaths> renameQueue;
	FilePaths currentFile;

	for (const auto &entry : std::filesystem::directory_iterator(pathToFolder))
	{
		std::string pathToFile = entry.path();
		int index = pathToFile.find_last_of("/\\");
		std::string fileName = pathToFile.substr(index+1);

		if(numberCheck(fileName))
		{
			int index = findSeparator(fileName);
			if(index != 0)
			{
				fileName = numberRemove(fileName, index);
			};

			std::string newName = pathToFolder + "/" + static_cast<std::string>(fileName);

			currentFile.originalPath = pathToFile;
			currentFile.newPath = newName;
			renameQueue.push_back(currentFile);
		};
	};

	renameFile(renameQueue);
}

void argumentsProcessing(std::vector<char> &optionsArray, std::vector<std::string> &pathsArray, std::string &launchFolder)
{
	for (int pathNumber = 0; pathNumber < pathsArray.size(); ++pathNumber)
	{

		for (int optionNumber = 0; optionNumber < optionsArray.size(); ++optionNumber)
		{
			switch(optionsArray[optionNumber])
			{
				case 'r':
				{
					randomizeFunction(pathsArray[pathNumber]);
					break;
				}
				case 'u':
				{
					unrandomizeFunction(pathsArray[pathNumber]);
					break;
				}
				case 'f':
				{
					filterFunction(pathsArray[pathNumber], launchFolder);
					break;
				}
				default:
				{
					throw WRONG_OPTION;
					break;
				}
			};
		};
	};
}

void argumentsValidator(int argc, char const *argv[], std::vector<char> &optionsArray, std::vector<std::string> &pathsArray)
{
	if (argv[1][0] != '-')
	{
		throw WRONG_OPTION;
	};

	for (int optionNumber = 1; optionNumber < strlen(argv[1]); ++optionNumber)
	{
		switch(argv[1][optionNumber])
		{
			case 'r':
			case 'u':
			case 'f':
			{
				optionsArray.push_back(argv[1][optionNumber]);
				break;
			}
			default:
			{
				throw WRONG_OPTION;
				break;
			}
		};
	};

	for (int pathNumber = 2; pathNumber < argc; ++pathNumber)
	{
		switch(argv[pathNumber][0])
		{
			case '/':
			{
				if (!std::filesystem::exists(argv[pathNumber]) && !std::filesystem::is_directory(argv[pathNumber]))
				{
					throw PATH_DO_NOT_EXIST;
				}
				else
				{
					pathsArray.push_back(argv[pathNumber]);
				};
				break;
			}
			default:
			{
				throw WRONG_PATH;
				break;
			}
		};
	};
}

void printHelp(){
	std::cout
	<< "usage: for [-ru] [\"/path/to/folder\"] ...\n-r  randomize files in folder." << std::endl 
	<< "-u  unrandomize files in folder.\n-f  filter files in folder." << std::endl;
}

int main(int argc, char const *argv[])
{
	std::vector<char> optionsArray;
	std::vector<std::string> pathsArray;
	std::string launchFolder = argv[0];

	switch(argc)
	{
		case 0:
		case 1:
		case 2:
		{
			printHelp();
			break;
		}
		default:
		{
			try
			{
				argumentsValidator(argc, argv, optionsArray, pathsArray);
				argumentsProcessing(optionsArray, pathsArray, launchFolder);	
			}
			catch(Errors errorNumber)
			{
				switch(errorNumber)
				{
					case WRONG_OPTION:
					{
						std::cout << "Unrecognized option(s)." << std::endl;
						printHelp();
					}
					case WRONG_PATH:
					{
						std::cout << "Unrecognized path(s)." << std::endl;
						printHelp();
					}
					case PATH_DO_NOT_EXIST:
					{
						std::cout << "Path do not exist or leads to file." << std::endl;
						printHelp();
					}
				};
			};
		}
	};

	return 0;
}